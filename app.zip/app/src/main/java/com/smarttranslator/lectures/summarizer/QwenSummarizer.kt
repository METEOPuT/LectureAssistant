package com.smarttranslator.lectures.summarizer

import ai.nobodywho.Chat
import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext

class QwenSummarizer(
    private val modelPath: String = "hf://Qwen/Qwen2.5-0.5B-Instruct-GGUF/qwen2.5-0.5b-instruct-q4_k_m.gguf",
    private val onProgress: (Float) -> Unit = {}
) : Summarizer {

    override val name = "Qwen2.5-0.5B"

    // Храним экземпляр чата в памяти, чтобы не загружать модель заново
    private var chatInstance: Chat? = null
    private val mutex = Mutex()

    private suspend fun getChat(): Chat = mutex.withLock {
        chatInstance ?: Chat.fromPath(modelPath) { downloaded, total ->
            if (total > 0UL) {
                onProgress((downloaded.toDouble() / total.toDouble()).toFloat())
            }
        }.also { chatInstance = it }
    }

    override suspend fun summarize(text: String): Result<String> = withContext(Dispatchers.IO) {
        try {
            val chat = getChat()
            // Для маленьких моделей промпт должен быть максимально простым
            val prompt = "Кратко законспектируй следующий текст:\n\n$text\n\nКонспект:"

            Log.d("QwenDebug", "Отправка запроса в модель...")
            val response = chat.ask(prompt).completed()
            Log.d("QwenDebug", "Модель ответила: $response")

            if (response.isBlank()) {
                Result.failure(Exception("Модель вернула пустой ответ"))
            } else {
                Result.success(response.trim())
            }
        } catch (e: Exception) {
            Log.e("QwenDebug", "Ошибка генерации", e)
            Result.failure(e)
        }
    }
}